<div>
    ФИО: {{ $fio }} <br>
    E-mail: {{ $email }} <br>
    Вопрос: {{ $text }} <br>
</div>