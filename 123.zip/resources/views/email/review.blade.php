<div>
    Отзыв c сайта
    <br>
    ФИО: {{ $fio }} <br>
    E-mail: {{ $email }} <br>
    Текс: {{ $text }} <br>
</div>