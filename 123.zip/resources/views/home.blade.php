@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center py-4">
            <img src="img/logo.png">
            <h1>ДОБРО ПОЖАЛОВАТЬ!</h1>
        </div>
    </div>
</div>
@endsection
